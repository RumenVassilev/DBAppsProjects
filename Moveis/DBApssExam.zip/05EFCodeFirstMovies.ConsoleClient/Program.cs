﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _05EFCodeFirstMovies;

namespace _05EFCodeFirstMovies.ConsoleClient
{
    class Program
    {
        static void Main()
        {
            
        }
    }
}
